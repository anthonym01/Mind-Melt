# Dependencies  

- ply
- venv
- Flask

## Settup Linux/Mac

run

```sh
cd Yourkoza2 && python3 -m venv .venv && . .venv/bin/activate && pip install Flask && pip install ply
```

## Settup Windows

run

```bash
cd Yourkoza2 ; py -3 -m venv .venv ; .venv\Scripts\activate ; pip install Flask ; pip install ply
```
